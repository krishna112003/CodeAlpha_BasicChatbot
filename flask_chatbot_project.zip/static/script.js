function sendMessage() {
    const inputBox = document.getElementById("userInput");
    const userText = inputBox.value.trim();

    if (!userText) return;

    const chatbox = document.getElementById("chatbox");
    chatbox.innerHTML += `<p><strong>You:</strong> ${userText}</p>`;
    inputBox.value = "";

    fetch(`/get?msg=${encodeURIComponent(userText)}`)
        .then(response => response.json())
        .then(data => {
            chatbox.innerHTML += `<p><strong>Bot:</strong> ${data.response}</p>`;
            chatbox.scrollTop = chatbox.scrollHeight;
        });
}
